//! [0]
g.setTitle("&User information")
//! [0]
