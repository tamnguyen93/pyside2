//! [0]
xmlReader.setFeature("http://xml.org/sax/features/namespace-prefixes", True)
//! [0]
