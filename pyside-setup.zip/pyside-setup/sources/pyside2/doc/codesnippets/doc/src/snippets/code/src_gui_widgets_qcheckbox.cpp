//! [0]
checkbox = QCheckBox("C&ase sensitive", self)
//! [0]
