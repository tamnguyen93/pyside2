.. _installing_linux:

Installing PySide on a Linux System
===================================

We do not provide binaries for Linux. Please read
the build instructions in section
`Building PySide on a Linux System
<http://pyside.readthedocs.org/en/latest/building/linux.html>`_.
