.. toctree::
   :maxdepth: 2

.. include:: ../CHANGES.rst
