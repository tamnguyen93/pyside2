Building PySide
===============

.. toctree::
   :maxdepth: 2

   windows.rst
   macosx.rst
   linux.rst
   options.rst
